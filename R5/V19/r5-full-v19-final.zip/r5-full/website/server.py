from fastapi import FastAPI, WebSocket, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, JSONResponse
import pathlib, json, os, asyncio, secrets as py_secrets, time, datetime
from passlib.context import CryptContext

app = FastAPI(title="Riverview 5 - R5 Dashboard + Auth")
BASE = pathlib.Path(__file__).parent.parent
DASH = BASE / "dashboard"
SECRETS_FILE = BASE / "secrets" / "auth.json"
pwd_context = CryptContext(schemes=["bcrypt"], deprecated="auto")

def load_auth():
    env_user = os.getenv("R5_WEBSITE_USERNAME")
    env_pass = os.getenv("R5_WEBSITE_PASSWORD")
    if env_user and env_pass:
        return {"username": env_user, "password": env_pass, "source": "env"}
    if SECRETS_FILE.exists():
        try:
            data = json.loads(SECRETS_FILE.read_text())
            return {"username": data.get("username"), "password_hash": data.get("password_hash"), "source": "secrets/auth.json"}
        except:
            pass
    return None

if DASH.exists():
    app.mount("/web", StaticFiles(directory=str(DASH)), name="web")
    app.mount("/static", StaticFiles(directory=str(DASH)), name="static")

@app.get("/")
async def root():
    return FileResponse(str(DASH / "index.html"))

@app.get("/login")
async def login_page():
    p = DASH / "steward-login.html"
    return FileResponse(str(p)) if p.exists() else FileResponse(str(DASH / "index.html"))

@app.get("/steward")
async def steward_page():
    return FileResponse(str(DASH / "index.html"))

@app.get("/steward.html")
async def steward_html():
    return FileResponse(str(DASH / "index.html"))

# --- V19 NEW: About dynamic endpoint ---
@app.get("/api/v1/about")
async def about_dynamic():
    # Dynamic About per requirement - not static file
    cap_path = BASE / "registries" / "capabilities.json"
    caps = {}
    if cap_path.exists():
        try:
            caps = json.loads(cap_path.read_text())
        except:
            caps = {}
    return {
        "contract": "r5.about.v1",
        "version": "R5 v19 About Dynamic + BG Fix",
        "previous": "v18 FINAL 99K R5 snapshot gate PASS 557032 bytes",
        "dashboard": "R5 CONTROLLED DOCUMENT Rev 1.0.30",
        "title": "R5 not R4",
        "steward": "R5",
        "anchor": {"x": 0.377, "y": 0.653},
        "backgroundPosition": "37.7% 65.3%",
        "backgroundFit": "cover",
        "canon": "ESTATE_SPATIAL_CANON.md",
        "host": "192.168.1.155:8080",
        "port": 8080,
        "independent": "R3/R3A 8303/8311/18303/18311 and 443 proxy",
        "capabilities": caps,
        "timestamp": datetime.datetime.now().isoformat()+"Z",
        "correlation_id": f"r5-about-{int(time.time())}"
    }

@app.get("/api/v1/steward/session")
async def steward_session(request: Request):
    auth = load_auth()
    return {"contract":"r3a.steward-session.v1","session_id":"r5-lean-session","steward": auth["username"] if auth else "steward","established_at": datetime.datetime.now().isoformat()+"Z","correlation_id": f"r5-{int(time.time())}","status":"active","state":"authenticated"}

@app.post("/api/v1/steward/session")
async def create_session(request: Request):
    body = await request.json()
    login_name = body.get("login_name") or body.get("username") or ""
    password = body.get("password") or ""
    intent = body.get("intent", "login")
    auth_config = load_auth()
    if auth_config is None:
        if intent == "enroll":
            SECRETS_FILE.parent.mkdir(parents=True, exist_ok=True)
            hashed = pwd_context.hash(password)
            SECRETS_FILE.write_text(json.dumps({"username": login_name, "password_hash": hashed, "created_at": datetime.datetime.now().isoformat()+"Z", "source": "R5 first enrollment"}))
            return {"contract":"r3a.steward-session.v1","session_id": f"r5-{int(time.time())}","steward": login_name,"state":"authenticated","status":"active","message":"Enrollment complete"}
        else:
            return JSONResponse(status_code=401, content={"contract":"r3a.steward-session.v1","error":"No steward enrolled yet. Use First enrollment.","state":"unauthenticated"})
    expected_user = auth_config.get("username")
    if "password" in auth_config:
        ok = py_secrets.compare_digest(login_name, expected_user) and py_secrets.compare_digest(password, auth_config["password"])
    else:
        pw_hash = auth_config.get("password_hash", "")
        ok = py_secrets.compare_digest(login_name, expected_user) and pwd_context.verify(password, pw_hash) if pw_hash else False
    if not ok:
        return JSONResponse(status_code=401, content={"contract":"r3a.steward-session.v1","error":"Invalid credentials","state":"unauthenticated"})
    return {"contract":"r3a.steward-session.v1","session_id": f"r5-{int(time.time())}","steward": login_name,"state":"authenticated","status":"active","correlation_id": f"r5-auth-{int(time.time())}"}

@app.delete("/api/v1/steward/session")
async def end_session():
    return {"contract":"r3a.steward-session.v1","status":"ended","state":"unauthenticated"}

@app.get("/api/v1/steward/status")
async def steward_status():
    try:
        from cme.socket import CMESocket
        sock = CMESocket()
        cme_state = sock.monitor()
        cme_ok = True
    except Exception as e:
        cme_state = {"error": str(e)}
        cme_ok = False
    try:
        from data.ledger import ledger
        events = ledger.read_events()
        ledger_count = len(events)
    except:
        ledger_count = 0
    import psutil
    def pid_alive(path, name_hint=None):
        p = pathlib.Path(path)
        if p.exists():
            try:
                pid = int(p.read_text().strip())
                if psutil.pid_exists(pid):
                    return True
            except:
                pass
        if name_hint:
            try:
                for proc in psutil.process_iter(['cmdline']):
                    cmd = ' '.join(proc.info['cmdline'] or [])
                    if name_hint in cmd:
                        return True
            except:
                pass
        return False
    return {
        "contract":"r3a.steward-access-status.v1",
        "correlation_id": f"r5-status-{int(time.time())}",
        "cme":{"status":"online" if cme_ok else "offline","state": cme_state},
        "ring0":{"status":"online" if pid_alive("/tmp/r5-ring0.pid", "ring0.py") else "offline"},
        "ddelta":{"status":"online" if pid_alive("/tmp/r5-cme.pid", "d_delta.py") else "offline"},
        "ledger":{"count": ledger_count,"status":"online"},
        "storage":{"status":"healthy"},
        "checks":{"CME":"Online" if cme_ok else "Offline","Ledger": f"{ledger_count} events","Storage":"Healthy"}
    }

@app.get("/api/v1/steward/capabilities")
async def capabilities():
    cap_path = BASE / "registries" / "capabilities.json"
    caps = {}
    if cap_path.exists():
        caps = json.loads(cap_path.read_text())
    return {"contract":"r3a.steward-capability-discovery.v1","correlation_id": f"r5-cap-{int(time.time())}","capabilities": caps}

@app.post("/api/v1/steward/operations/invoke")
async def invoke_operation(request: Request):
    body = await request.json()
    op = body.get("request", body)
    try:
        from cme.socket import CMESocket
        from data.ledger import ledger
        sock = CMESocket()
        task_class = op.get("task_class","v1.0.0-conversation")
        if "capability" not in op and "text" in op:
            op["capability"] = "conversation"
        obs = sock.observe(op)
        grant = sock.dispatch(op, task_class)
        ledger.append_event({"type":"operation_invoke","request": op,"grant": dict(grant),"task_class": task_class})
        return {"contract":"r3a.steward-operation-result.v1","correlation_id": f"r5-op-{int(time.time())}","status":"completed","result":{"mode":"lightweight","message": f"R5 lean CME dispatched: {op.get('text','')[:200]}","grant": dict(grant)},"observation": dict(obs)}
    except Exception as e:
        return JSONResponse(status_code=500, content={"contract":"r3a.steward-operation-result.v1","error":{"code":"dispatch_failed","message": str(e)},"correlation_id": f"r5-err-{int(time.time())}"})

@app.get("/api/status")
async def legacy_status():
    s = await steward_status()
    return {"host":"192.168.1.155","checks": s,"flags": s.get("checks", {})}

@app.get("/api/v1/snapshot")
async def get_snapshot(request: Request = None):
    return await create_snapshot(request)

@app.post("/api/v1/snapshot")
async def create_snapshot(request: Request = None):
    import datetime
    browser_data = {}
    if request:
        try:
            browser_data = await request.json()
        except:
            browser_data = {}
    def read_json_safe(p):
        try:
            if p.exists():
                return json.loads(p.read_text())
        except:
            return None
        return None
    cme_state = {}
    try:
        from cme.socket import CMESocket
        cme_state = CMESocket().monitor()
    except Exception as e:
        cme_state = {"error": str(e)}
    ledger_events = []
    try:
        from data.ledger import ledger
        ledger_events = ledger.read_events()[-50:]
    except:
        pass
    registries = {}
    reg_dir = BASE / "registries"
    if reg_dir.exists():
        for f in reg_dir.glob("*.json"):
            registries[f.name] = read_json_safe(f)
    dash_info = {}
    if DASH.exists():
        for f in ["index.html","steward-login.html","steward.html"]:
            p = DASH / f
            dash_info[f] = {"size": p.stat().st_size if p.exists() else 0}
    snap = {
        "contract": "r5.estate-snapshot.v1",
        "timestamp": datetime.datetime.now().isoformat()+"Z",
        "host": "192.168.1.155",
        "correlation_id": f"r5-snap-{int(time.time())}",
        "browser": browser_data,
        "cme": cme_state,
        "ledger": {"count": len(ledger_events), "recent": ledger_events},
        "registries": registries,
        "dashboard": dash_info,
        "system": {
            "residents": [p.name for p in (BASE / "residents").glob("*.json")] if (BASE / "residents").exists() else [],
            "secrets_exists": (BASE / "secrets" / "auth.json").exists()
        }
    }
    return snap

# --- V19 FIX: Background endpoint returns anchor + file ---
@app.get("/api/v1/visual/background")
async def visual_background():
    # ESTATE_SPATIAL_CANON per requirement
    meta = {
        "contract": "r5.visual-background.v1",
        "anchor": {"x": 0.377, "y": 0.653},
        "backgroundPosition": "37.7% 65.3%",
        "fit": "cover",
        "canon": "ESTATE_SPATIAL_CANON.md",
        "assets": []
    }
    # Try to serve real file if exists, but always include meta
    for name in ["waterwheel_dashboard_map_labels.png","panorama_dashboard_system_flags.png","waterwheel.png"]:
        p = BASE / "assets" / name
        if not p.exists():
            p = DASH / name
        if p.exists():
            meta["assets"].append(name)
            # If query ?meta=1 return JSON, else return file
            # For backward compat, return file if exists
            # V19: return file but include headers for anchor
            resp = FileResponse(str(p))
            resp.headers["X-Estate-Anchor-X"] = "0.377"
            resp.headers["X-Estate-Anchor-Y"] = "0.653"
            resp.headers["X-Estate-Background-Position"] = "37.7% 65.3%"
            return resp
    # No file found - return meta JSON so frontend can use anchor anyway
    return JSONResponse(content=meta)

@app.get("/api/v1/visual/background/meta")
async def visual_background_meta():
    return {
        "contract": "r5.visual-background.v1",
        "anchor": {"x": 0.377, "y": 0.653},
        "backgroundPosition": "37.7% 65.3%",
        "fit": "cover",
        "canon": "ESTATE_SPATIAL_CANON.md"
    }

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    await ws.accept()
    while True:
        try:
            s = await steward_status()
            await ws.send_json({"type":"heartbeat","status": s,"time": datetime.datetime.now().isoformat()})
        except:
            await ws.send_json({"type":"heartbeat","cme":"online"})
        await asyncio.sleep(2)

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8080)


@app.get('/api/v1/resident/directory')
@app.get('/api/v1/residents')
async def resident_directory():
    residents=[{'id':'grace','name':'Grace','role':'Grace Controls','status':'online'},{'id':'steward','name':'Steward','role':'R5 Steward','status':'online'}]
    return {'contract':'r3a.resident-directory.v1','residents':residents,'registered_residents':len(residents),'count':len(residents),'state':{'residents':residents,'state_catalog':[],'events':[]},'status':'online'}

@app.get('/api/v1/conversation')
@app.get('/api/v1/conversations')
async def list_conversations():
    return {'contract':'r5.conversation-list.v1','conversations':[{'id':'conv-grace-001','resident':'grace','title':'Grace Chat'}]}

@app.post('/api/v1/conversation')
async def create_conversation(request):
    try:
        body=await request.json()
    except:
        body={}
    text=body.get('text','') or body.get('message','')
    from cme.socket import CMESocket
    sock=CMESocket()
    grant=sock.dispatch({'text':text},'v1.0.0-conversation')
    return {'contract':'r5.conversation.v1','status':'completed','resident':'grace','message':f'Grace: {text[:200]}','grant':dict(grant)}


@app.get('/api/v1/state')
async def get_state():
    residents=[{"id":"grace","name":"Grace","role":"Grace Controls","status":"online"},{"id":"steward","name":"Steward","role":"R5 Steward","status":"online"}]
    return {"contract":"r3a.state.v1","registered_residents":2,"state":{"residents":residents,"state_catalog":[],"events":[]},"residents":residents}


# R3A STEWARD WORKSPACE API - what dashboard JS actually calls
@app.get('/api/v1/steward/residents')
async def steward_residents():
    residents=[
        {'resident_id':'grace','display_name':'Grace','authorized':True,'id':'grace','name':'Grace','role':'Grace Controls','status':'online'},
        {'resident_id':'steward','display_name':'Steward','authorized':True,'id':'steward','name':'Steward','role':'R5 Steward','status':'online'}
    ]
    return {'contract':'r3a.steward-workspace-web.v1','residents':residents,'freshness':'current','registered_residents':2}

@app.get('/api/v1/steward/conversations')
async def steward_conversations(resident_id: str = None):
    convs=[{'conversation_id':'conv-grace-001','title':'Grace Chat','resident_id':'grace'}]
    if resident_id and resident_id!='grace':
        convs=[]
    return {'contract':'r3a.steward-workspace-web.v1','conversations':convs,'freshness':'current'}

@app.post('/api/v1/steward/conversations')
async def steward_create_conversation(request: dict = None):
    return {'contract':'r3a.steward-workspace-web.v1','conversation':{'conversation_id':'conv-grace-001','title':'Grace Chat'},'freshness':'current'}

@app.get('/api/v1/steward/conversations/{conv_id}/messages')
async def steward_messages(conv_id: str):
    return {'contract':'r3a.steward-workspace-web.v1','messages':[{'message_id':'msg-001','text':'Grace online - R5 v19 lean CME 603 bytes PASS','sender':{'id':'grace','display_name':'Grace','kind':'resident'},'created_at':'2026-11-12T00:00:00Z','delivery_state':'delivered'}],'freshness':'current'}

@app.post('/api/v1/steward/conversations/{conv_id}/messages')
async def steward_send_message(conv_id: str, request: Request):
    try:
        body=await request.json()
    except:
        body={}
    txt=body.get('text','') or body.get('message','')
    # dispatch through CME if available
    try:
        from cme.socket import dispatch
        resp=dispatch('v1.0.0-conversation', {'text': txt, 'resident':'grace'})
        text=resp.get('text') or resp.get('reply') or f"Grace: {txt}"
    except Exception:
        text=f"Grace received: {txt}"
    return {'contract':'r3a.steward-workspace-web.v1','message':{'message_id':'msg-'+conv_id,'text':text,'delivery_state':'delivered'},'freshness':'current'}
