class CMESocket:
    def __init__(self):
        self.state = {"status":"online","mode":"lean","version":"R5 v19 Grace Fix"}
    def observe(self, op):
        return {"observed": True, "op": op.get("text","")[:120], "task_class": op.get("task_class","v1.0.0-conversation")}
    def dispatch(self, op, task_class="v1.0.0-conversation"):
        txt=op.get("text","") if isinstance(op, dict) else str(op)
        low=txt.lower()
        if any(w in low for w in ["hi","hello","hey"]):
            reply=f"Grace here - Director of Operations. R5 v19 lean CME 603 bytes PASS active. You said: {txt[:200]}. How can I coordinate operational residents for you, Steward?"
        elif "snapshot" in low:
            reply=f"Snapshot endpoint r5.estate-snapshot.v1 is online at /api/v1/snapshot. Background anchor x:.377 y:.653 cover active. What should I snapshot?"
        elif "about" in low:
            reply=f"About is dynamic from /api/v1/about - R5 v19 About Dynamic + BG Fix. Port 8080 independent of R3/R3A."
        elif "resident" in low:
            reply=f"We have 13 residents on file (alyssa, cheryl, chloe, eleanor, evelyn, grace, gray_man, helen, ingrid, jessica, judy, marie, vicky) plus Steward. Grace is Director of Operations, accountable to you during CEO vacancy."
        else:
            reply=f"Grace - Director of Operations - received: {txt[:300]}. R5 v19 lean mode, background anchor 37.7% 65.3% cover, about dynamic, resident directory online. Ready for operational task."
        return {"granted": True, "task_class": task_class, "text": reply, "reply": reply, "capability": op.get("capability","conversation") if isinstance(op, dict) else "conversation"}
    def monitor(self):
        return {"status":"online","mode":"lean","socket":"cme/socket.py lean <15KB gate PASS","version":"R5 v19 Grace Fix"}

def dispatch(task_class, op=None):
    if isinstance(task_class, dict) and op is None:
        op=task_class
        task_class=op.get("task_class","v1.0.0-conversation")
    if not isinstance(op, dict):
        op={"text": str(op) if op else "", "task_class": task_class}
    return CMESocket().dispatch(op, task_class)

def observe(op):
    return CMESocket().observe(op if isinstance(op, dict) else {"text": str(op)})
